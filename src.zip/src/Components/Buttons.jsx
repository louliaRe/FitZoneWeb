import React from "react";
import { Button } from "@mantine/core";

const Buttons=()=>{

    return(
      <Button>i am in the main</Button>
    )
}
export default Buttons;