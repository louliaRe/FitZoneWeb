import React from "react";
import { Card, Button } from "@mantine/core";

const floors=()=>{
   return(
      <Card>

        
      </Card>
   )
}
export default floors;